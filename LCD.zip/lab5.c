/* 
 * File:   lab5.c
 * Author: PC-11
 *
 * Created on July 16, 2020, 8:07 AM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

