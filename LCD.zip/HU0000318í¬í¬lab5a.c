/* 
 * File:   HU0000318??lab5a.c
 * Author: PC-11
 *
 * Created on July 16, 2020, 8:06 AM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

