/* 
 * File:   Hu000318_lab3a_asmLib_v001.h
 * Author: PC-11
 *
 * Created on June 23, 2020, 3:55 PM
 */

#ifndef HU000318_LAB3A_ASMLIB_V001_H
#define	HU000318_LAB3A_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif


void wait_50us(void);
void wait_1ms(void);

#ifdef	__cplusplus
}
#endif

#endif	/* HU000318_LAB3A_ASMLIB_V001_H */

