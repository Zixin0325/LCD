#include "xc.h"
#include <stdint.h>


void lcd_cmd(char command){

    I2C2CONbits.SEN = 1;            //start
    while(I2C2CONbits.SEN == 1);

    IFS3bits.MI2C2IF =0;            //address
    I2C2TRN = 0b01111100;
    
    while(IFS3bits.MI2C2IF == 0); 
    IFS3bits.MI2C2IF =0;            //control
    I2C2TRN = 0b00000000;

    while(IFS3bits.MI2C2IF == 0);
    IFS3bits.MI2C2IF =0;           //data
    I2C2TRN = command;
                      
    while(IFS3bits.MI2C2IF == 0);
    I2C2CONbits.PEN = 1;            //stop
                        
    while(I2C2CONbits.PEN );
    
}

void lcd_init(void){
    
    wait_n_ms(50);
    lcd_cmd(0b00111000); // function set, normal instruction mode
    lcd_cmd(0b00111001); // function set, extended instruction mode
    lcd_cmd(0b00010100); // interval osc
    lcd_cmd(0b01110000); // contrast C3-C0
    lcd_cmd(0b01011110); // Ion, Bon, C5-C4
    lcd_cmd(0b01101100); // follower control
    wait_n_ms(200);
    lcd_cmd(0b00111000); // function set, normal instruction mode
    lcd_cmd(0b00001100); // Display On
    lcd_cmd(0b00000001); // Clear Display
    wait_n_ms(2);
    
}

void lcd_setCursor(char x, char y){         //row y, column x
    
    int Cursor;
    
    Cursor = (0x40 * y + x) | 0x80;
    
    lcd_cmd(Cursor);
    
}

void lcd_printChar(char myChar){
    
    I2C2CONbits.SEN = 1;                //start
    
    while(I2C2CONbits.SEN);             //address
    IFS3bits.MI2C2IF =0;
    I2C2TRN = 0b01111100;
    
    while(IFS3bits.MI2C2IF == 0);       //control
    IFS3bits.MI2C2IF =0;    
    I2C2TRN = 0b01000000;
    
    while(IFS3bits.MI2C2IF == 0);      //data
    IFS3bits.MI2C2IF =0;            
    I2C2TRN = myChar; 
           
    while(IFS3bits.MI2C2IF == 0);       //stop
    I2C2CONbits.PEN = 0;
    
    while(I2C2CONbits.PEN );            //end
    
}

void lcd_printStr(const char s[]){
    
    int n = 0;
    int i = 0;
    int print = 0;

    while (s[n] != '\0'){           //count character number
        n++;
    }
    
    if(n <= 8){          //the number of character of first row
        i = n;
    }else{
        i = 8;
    }
    

        lcd_setCursor(0,0);
        I2C2CONbits.SEN = 1;            //start
        while(I2C2CONbits.SEN == 1);
        IFS3bits.MI2C2IF =0;            //address
        I2C2TRN = 0b01111100;

        while (i>1){                    

            while(IFS3bits.MI2C2IF == 0);                  
            IFS3bits.MI2C2IF =0;                
            I2C2TRN = 0b11000000;                //control:CO =1, RS = 1

            while(IFS3bits.MI2C2IF == 0);
            IFS3bits.MI2C2IF =0;                
            I2C2TRN = s[print];                   //data
            print++;
            i--;
        }

        while(IFS3bits.MI2C2IF == 0);
        IFS3bits.MI2C2IF =0;             
        I2C2TRN = 0b01000000;       //control:CO =0, RS = 1

        while(IFS3bits.MI2C2IF == 0);
        IFS3bits.MI2C2IF =0;            
        I2C2TRN = s[print];         //data

        while(IFS3bits.MI2C2IF == 0);
        I2C2CONbits.PEN = 1;            //stop
        while(I2C2CONbits.PEN );

            if(n>=9)
            {
                n = n-8;
                print ++;
                lcd_setCursor(0,1);

                I2C2CONbits.SEN = 1;            //start
                while(I2C2CONbits.SEN == 1);
                IFS3bits.MI2C2IF =0;            //address
                I2C2TRN = 0b01111100;

                while (n>1)
                {                    

                    while(IFS3bits.MI2C2IF == 0);                  
                    IFS3bits.MI2C2IF =0;                
                    I2C2TRN = 0b11000000;                //control:CO =1, RS = 1

                    while(IFS3bits.MI2C2IF == 0);
                    IFS3bits.MI2C2IF =0;                
                    I2C2TRN = s[print];                   //data
                    print++;
                    n--;

                }

                while(IFS3bits.MI2C2IF == 0);
                IFS3bits.MI2C2IF =0;             
                I2C2TRN = 0b01000000;       //control:CO =0, RS = 1

                while(IFS3bits.MI2C2IF == 0);
                IFS3bits.MI2C2IF =0;            
                I2C2TRN = s[print];         //data

                while(IFS3bits.MI2C2IF == 0);
                I2C2CONbits.PEN = 1;            //stop
                while(I2C2CONbits.PEN );
            }
    
}
